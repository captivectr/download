import ctypes
import subprocess
import os

# Function to check if the script is running as an administrator
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

# Path to the target item
target_item = r"C:\Users\ketgi\Desktop\Caffe.lnk"

# PowerShell script to pin the item to the taskbar
powershell_script = f'''
$Target = "{target_item}"
$Shell = New-Object -ComObject Shell.Application
$Folder = $Shell.Namespace((Get-Item $Target).DirectoryName)
$Item = $Folder.ParseName((Get-Item $Target).Name)
$Item.InvokeVerb("Pin to Taskbar")
'''

# If the script is running as admin, run the PowerShell command directly
if is_admin():
    subprocess.run(["powershell", "-ExecutionPolicy", "Bypass", "-Command", powershell_script])
else:
    # If not running as admin, relaunch the script as admin
    ctypes.windll.shell32.ShellExecuteW(
        None, "runas", "powershell",
        f"-ExecutionPolicy Bypass -Command {powershell_script}", None, 1
    )
